package app;
import java.sql.*;
public final class DB { private DB(){} public static Connection get() throws SQLException { String url=env("DB_URL","jdbc:mysql://mysql:3306/course_feedback?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"); return DriverManager.getConnection(url,env("DB_USER","appuser"),env("DB_PASSWORD","appsecret")); } private static String env(String k,String d){String v=System.getenv(k);return v==null||v.isBlank()?d:v;} }
