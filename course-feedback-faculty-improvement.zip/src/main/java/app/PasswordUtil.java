package app;
import java.nio.charset.StandardCharsets;import java.security.*;import java.util.HexFormat;
public final class PasswordUtil { private PasswordUtil(){} public static String hash(String v){try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(v.getBytes(StandardCharsets.UTF_8)));}catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}} public static boolean matches(String v,String h){return MessageDigest.isEqual(hash(v).getBytes(StandardCharsets.US_ASCII),h.getBytes(StandardCharsets.US_ASCII));} }
