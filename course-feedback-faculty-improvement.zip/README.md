# Course Feedback and Faculty Improvement System

Java 17+ / Jakarta Servlet 6 / JSP / MySQL 8. The application is packaged as a WAR and deployed as the root web app in Tomcat, avoiding project-context 404 mistakes.

## Run online without installing local software

Use a cloud development environment that supports Docker Compose, such as GitHub Codespaces. Create a repository, upload the contents of this project, open the repository in a Codespace, and run:

```bash
docker compose up --build
```

Wait for MySQL health and Tomcat startup. Open the forwarded **8080** port in the Codespaces Ports panel. Because the WAR is deployed as `ROOT.war`, open the forwarded URL itself, without adding `/computer-service-center` or another project path.

Troubleshooting:
- Logs: `docker compose logs -f app mysql`
- Restart: `docker compose down` then `docker compose up --build`
- Reinitialize the demo database after changing `database/init.sql`: `docker compose down -v` then `docker compose up --build` (this deletes the container database volume).
- From inside the application container, the database hostname is `mysql`, not `localhost`.

## Demo accounts
- `admin` / `admin123` — ADMIN
- `faculty` / `faculty123` — FACULTY
- `student` / `student123` — STUDENT

## Included functionality
- Session-based login/logout and role-specific visibility/actions.
- Create records, update workflow status, delete records as administrator.
- MySQL persistence, prepared statements, input checks, responsive JSP/CSS interface.
- Course feedback, 1–5 rating, comments, faculty improvement actions and progress.

## Build verification
This source package was generated with Maven/Tomcat/Docker configuration. In the generation environment, Java was available but Maven was not installed, and a Docker runtime was not available for a full build/deployment test. Therefore a successful build or zero runtime errors cannot be claimed here. Run the Compose command above in the target cloud environment and inspect the logs if it fails.

## Security limitation
Demo passwords are SHA-256 hashed, but SHA-256 is not appropriate for production password storage. Use BCrypt/Argon2, HTTPS, CSRF tokens, audit logging, strict record-level authorization, managed secrets, and security review before real deployment. Do not use this classroom demo for real sensitive counselling records or confidential institutional data.
