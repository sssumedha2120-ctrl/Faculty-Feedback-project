#!/usr/bin/env sh
set -eu
URL="${1:-http://localhost:8080/}"
echo "Checking $URL"
curl --fail --silent --show-error "$URL" >/tmp/app-smoke.html
grep -q "Sign in" /tmp/app-smoke.html
echo "HTTP login page check passed."
